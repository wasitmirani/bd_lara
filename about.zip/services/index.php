<?php include '../inc/meta.php'; ?>
<title>Digital Iconix | Services</title>
</head>
<body>
<?php include '../inc/header.php'; ?>

    <!-- Main-content -->
    <section class="banner inner-banner">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-8 m-auto">
            <h1 class="sec-heading"> <span class="underline-text-color"></span> <span class="underline-text-color">SERVICES</span> </h1>
          </div>
        </div>
      </div>
    </section>
    <!-- Main-content -->
    <!-- Services -->
    <section class="services">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-12">
            <h2 class="hd">EXPLORE OUR SERVICES</h2>
            <h2 class="sec-heading">We combine <span class="underline-text-color">smart design</span> with rich <span class="underline-text-color2">technology</span>.</h2>
          </div>
        </div>
        <!-- first -->
        <div class="service-in">
          <div class="row">
            <div class="col-lg-5">
              <div class="img-box"><img src="/assets/images/web-design.png" class="img-fluid" alt=""></div>
            </div>
            <div class="col-lg-7 dis-flex">
              <div class="content">
                <h2 class="sec-heading"> <span class="underline-text-color">WEBSITE DESIGN </span> &  DEVELOPMENT</h2>
                <p>Our custom website designing services are created, keeping your business goals in mind. We combine technical expertise and creative instincts to create unique and extraordinary solutions for your business.</p>
                <p>We understand that websites make businesses, the entire business may depend upon websites, so it is important to learn about business requirements and objectives first, and then plan about the website. We are a design agency, that is focused on business goals and the customer’s psyche.</p>
                <table style="height: 65px; border: 0px solid #ffffff !important;" border="0" width="562" cellpadding="10">
                  <tbody>
                    <tr>
                      <td><span style="color: #eb2f5b;"><strong>Custom Website Design</strong></span></td>
                      <td><span style="color: #eb2f5b;"><strong>Responsive Website</strong></span></td>
                    </tr>
                    <tr>
                      <td><span style="color: #eb2f5b;"><strong>Custom Management System</strong></span></td>
                      <td><span style="color: #eb2f5b;"><strong>Landing Page Design</strong></span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!-- first -->
        <!-- 2nd -->
        <div class="service-in">
          <div class="row">
            <div class="col-lg-7 dis-flex">
              <div class="content">
                <h2 class="sec-heading"> <span class="underline-text-color">MOBILE  </span> APPS</h2>
                <p>Amplify digitally with Digital Iconix’s remarkable knack in mobile app development. The highly experienced and passionate team of Digital Iconix is rewarded with the unconventional wisdom of designing breakthrough mobile apps that improvise brand repute, boost the performance indicators and increase the sales incredibly. We discern the pulse of your business needs accurately after a sincere one to one conversation with you and then come out with an interesting mobile app solution that completely fits your company’s needs. Do you have an Idea? We can deliver you an exceptional mobile app that is an absolute olio of creativity and profitability.</p>
                <table style="height: 65px; border: 0px solid #ffffff !important;" border="0" width="562" cellpadding="10">
                  <tbody>
                    <tr>
                      <td><span style="color: #eb2f5b;"><strong>iOS Apps Development</strong></span></td>
                      <td><span style="color: #eb2f5b;"><strong>Android Apps Development</strong></span></td>
                    </tr>
                    <tr>
                      <td><span style="color: #eb2f5b;"><strong>Games Development</strong></span></td>
                      <td><span style="color: #eb2f5b;"><strong>Cross Platform</strong></span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="col-lg-5">
              <div class="img-box"><img src="/assets/images/mobile-apps.png" class="img-fluid" alt=""></div>
            </div>
          </div>
        </div>
        <!-- 2nd -->
        <!-- 3rd -->
        <div class="service-in">
          <div class="row">
            <div class="col-lg-5">
              <div class="img-box"><img src="/assets/images/ecommerce-solutions.png" class="img-fluid" alt=""></div>
            </div>
            <div class="col-lg-7 dis-flex">
              <div class="content">
                <h2 class="sec-heading"> <span class="underline-text-color">ECOMMERCE  </span>  SOLUTIONS</h2>
                <p>Digital Iconix focuses on custom e-commerce solutions & custom website shopping cart development that fit your business challenges. Our e-commerce initiatives improve sales performances, customer satisfaction, reports and marketing initiatives undertaken by a company. We make selling online easy for online retailers.</p>
                <p>Whatever your business is Digital Iconix can help you market and sell your products and services more cost-effectively. With designs that stand out from the crowd, we offer small businesses and corporate enterprises innovative and unique ways to sell on the web.</p>
                <table style="height: 65px; border: 0px solid #ffffff !important;" border="0" width="562" cellpadding="10">
                  <tbody>
                    <tr>
                      <td><span style="color: #eb2f5b;"><b>High Volume Capable</b></span></td>
                      <td><span style="color: #eb2f5b;"><strong>Truly Scalable</strong></span></td>
                    </tr>
                    <tr>
                      <td><span style="color: #eb2f5b;"><strong>Secure Payment Systems</strong></span></td>
                      <td><span style="color: #eb2f5b;"><strong>On-Time &amp; On-Budget</strong></span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!-- 3rd -->
        <!-- 4th -->
        <div class="service-in">
          <div class="row">
            <div class="col-lg-7 dis-flex">
              <div class="content">
                <h2 class="sec-heading"> <span class="underline-text-color">BRANDING  </span> </h2>
                <p>Our small business branding services help companies last a lifetime. Building a brand is about the experience that people have when they interact with your business. In world of endless noise, we help small businesses stand out of the crowd by pairing your brand with exceptional marketing best practices. Thus creating a focused, niche and unique brand.</p>
                <p>Your potential customers will form an opinion about your brand within the first 3 seconds of interacting with it. They are judging your brand’s logo, your design, and your content. The outcome will determine if they trust your business, or not. Why should they choose your business? Great branding will help you stand out from the competition, establish trust, and ultimately drive more sales for your business.</p>
                <table style="height: 65px; border: 0px solid #ffffff !important;" border="0" width="562" cellpadding="10">
                  <tbody>
                    <tr>
                      <td><span style="color: #eb2f5b;"><strong>Brand Strategy Development</strong></span></td>
                      <td><span style="color: #eb2f5b;"><strong>Stationary Design</strong></span></td>
                    </tr>
                    <tr>
                      <td><span style="color: #eb2f5b;"><strong>Brand Identity Design</strong></span></td>
                      <td><span style="color: #eb2f5b;"><strong>Creative Brand Campaigns</strong></span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="col-lg-5">
              <div class="img-box"><img src="/assets/images/branding.png" class="img-fluid" alt=""></div>
            </div>
          </div>
        </div>
        <!-- 4th -->
        <!-- 5th -->
        <div class="service-in">
          <div class="row">
            <div class="col-lg-5">
              <div class="img-box"><img src="/assets/images/digital-marketing.png" class="img-fluid" alt=""></div>
            </div>
            <div class="col-lg-7 dis-flex">
              <div class="content">
                <h2 class="sec-heading"> <span class="underline-text-color">DIGITAL   </span> MARKETING</h2>
                <p>Bring in some innovation in your digital marketing strategy and get your online campaign off to a flyer. Digital Iconix is is committed to providing effective online solutions on every platform.</p>
                <p>One of the reasons we’re so confident in our ability to deliver amazing results is that we have experts in each key digital channel. From pay-per-click and SEO services to social, content, and PR, we work together to ensure our clients see the best results across every campaign through integrated internet marketing strategies. At Digital Iconix, efficiency and results are the name of the game.</p>
                <table style="height: 65px; border: 0px solid #ffffff !important;" border="0" width="562" cellpadding="10">
                  <tbody>
                    <tr>
                      <td><span style="color: #eb2f5b;"><b>PPC Management</b></span></td>
                      <td><span style="color: #eb2f5b;"><strong>Search Engine Optimization</strong></span></td>
                    </tr>
                    <tr>
                      <td><span style="color: #eb2f5b;"><strong>Content &amp; B2B Marketing</strong></span></td>
                      <td><span style="color: #eb2f5b;"><strong>Email Marketing</strong></span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!-- 5th -->
        <!-- 6th -->
        <div class="service-in">
          <div class="row">
            <div class="col-lg-7 dis-flex">
              <div class="content">
                <h2 class="sec-heading"> <span class="underline-text-color">SOCIAL MEDIA   </span> MARKETING</h2>
                <p>When people hear the term social media their minds usually head towards Twitter and Facebook, however, there are many platforms out there. Finding the ones where you can connect with your customers is the real key.</p>
                <p>Digital Iconix’s social media service is designed to keep you in total control of your messages across various social media networks, and is based on understanding your own unique business challenges and objectives. As with everything, one size rarely fits all and so our social media service puts the focus clearly on what matters most to your company.</p>
                <table style="height: 65px; border: 0px solid #ffffff !important;" border="0" width="562" cellpadding="10">
                  <tbody>
                    <tr>
                      <td><span style="color: #eb2f5b;"><strong>Campaign Plan &amp; Strategy</strong></span></td>
                      <td><span style="color: #eb2f5b;"><strong>Paid Media</strong></span></td>
                    </tr>
                    <tr>
                      <td><span style="color: #eb2f5b;"><strong>Community Management</strong></span></td>
                      <td><span style="color: #eb2f5b;"><strong>Content &amp; Asset Production</strong></span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="col-lg-5">
              <div class="img-box"><img src="/assets/images/social-media.png" class="img-fluid" alt=""></div>
            </div>
          </div>
        </div>
        <!-- 6th -->
      </div>
    </section>
    <!-- Services -->
    <!-- Featured Logo -->
    <section class="f_logo">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <h3 style="text-align: center;">Featured In:</h3>
            <div id="f_logo">
              <div class="item"><div class="img-box"><img src="/assets/images/11.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/22.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/33.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/44.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/55.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/66.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/77.png" class="img-fluid" alt=""></div></div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Featured Logo -->
    
 <!-- Footer -->
<?php include '../inc/footer.php'; ?>
<?php include '../inc/footer_script.php'; ?>
<!-- Footer -->