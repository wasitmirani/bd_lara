<?php include '../inc/meta.php'; ?>
<title>Designocracy | About</title>
</head>
<body>
<?php include '../inc/header.php'; ?>
<!-- Main-content -->
<section class="banner inner-banner">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-8 m-auto">
        <h1 class="sec-heading">We <span class="underline-text-color">create</span> &amp; <span class="underline-text-color">simplify</span> — brands, ecommerce and digital products</h1>
      </div>
    </div>
  </div>
</section>
<!-- Main-content -->
<!-- About -->
<section class="about">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="content">
          <h2 class="hd">WHO ARE WE</h2>
          <h2 class="sec-heading"><span class="underline-text-color2">world class</span> provider of web, mobile &amp; enterprise solutions.</h2>
          <p>Designocracy is a creative agency with a core focus on creative, content, technology & e-commerce. We help brands create amazing assets and provide the distribution platforms to tell their story and engage with their customers. We offer a suite of services, from large-scale e-commerce solutions to content creation for digital campaigns. Some of our core services include website development, web design, Shopify solutions, e-commerce, digital marketing & SEO, content creation, and branding. We partner with clients in various industries such as: fashion, luxury, finance, food and beverage, lifestyle, technology, and entertainment.</p>
          <p>We are a proactive team, providing quick, pointed, and strategic solutions that solve your immediate issues and build lasting results. At B+C, you will find a level of service that blows the competition away. Responsive, creative, and strategic: our sweet spot.</p>
        </div>
        <div class="row">
          <div class="col-lg-6">
            <h3>Our Vision<span class="accent-color">.</span></h3>
            <p>We believe that each digital touch-point is an opportunity to create meaningful interactions & build a connection with the audience.</p>
          </div>
          <div class="col-lg-6">
            <h3>Our MISSION<span class="accent-color">.</span></h3>
            <p>To provide our clients with top-notch digital solutions. To create an unparalleled user experience. To enable our team to learn, ideate, incubate, iterate, and scale.</p>
          </div>
        </div>
      </div>
      <div class="col-lg-6 dis-flex">
        <div class="img-box"><img src="/assets/images/about-side-img.png" class="img-fluid" alt=""></div>
      </div>
    </div>
  </div>
</section>
<!-- About -->
<!-- Testimonials -->
<?php include '../inc/testimonials.php'; ?>
<!-- Testimonials -->

<!-- Logos -->
<section class="logos">
  <div class="container ">
    <div class="row">
      <div class="col-lg-12">
        <div class="content">
          <h2 class="hd">OUR ACHIEVEMENTS</h2>
          <h1 class="sec-heading"><span class="underline-text-color">Awards &amp; Recognitions</span> over the years</h1>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-2"><div class="img-box"><img src="/assets/images/app-futura.png" class="img-fluid" alt=""></div></div>
      <div class="col-lg-2"><div class="img-box"><img src="/assets/images/best-digital-agency.png" class="img-fluid" alt=""></div></div>
      <div class="col-lg-2"><div class="img-box"><img src="/assets/images/clutch-react.png" class="img-fluid" alt=""></div></div>
      <div class="col-lg-2"><div class="img-box"><img src="/assets/images/clutch.png" class="img-fluid" alt=""></div></div>
      <div class="col-lg-2"><div class="img-box"><img src="/assets/images/goodfirms.png" class="img-fluid" alt=""></div></div>
      <div class="col-lg-2"><div class="img-box"><img src="/assets/images/softwareworld.png" class="img-fluid" alt=""></div></div>
    </div>
  </div>
</section>
<!-- Logos -->

<!-- Featured Logo -->
<section class="f_logo">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h3 style="text-align: center;">Featured In:</h3>
        <div id="f_logo">
          <div class="item"><div class="img-box"><img src="/assets/images/11.png" class="img-fluid" alt=""></div></div>
          <div class="item"><div class="img-box"><img src="/assets/images/22.png" class="img-fluid" alt=""></div></div>
          <div class="item"><div class="img-box"><img src="/assets/images/33.png" class="img-fluid" alt=""></div></div>
          <div class="item"><div class="img-box"><img src="/assets/images/44.png" class="img-fluid" alt=""></div></div>
          <div class="item"><div class="img-box"><img src="/assets/images/55.png" class="img-fluid" alt=""></div></div>
          <div class="item"><div class="img-box"><img src="/assets/images/66.png" class="img-fluid" alt=""></div></div>
          <div class="item"><div class="img-box"><img src="/assets/images/77.png" class="img-fluid" alt=""></div></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Footer -->
<?php include '../inc/footer.php'; ?>
<?php include '../inc/footer_script.php'; ?>
<!-- Footer -->