<?php include '../inc/meta.php'; ?>
<title>Designocracy | Quote</title>
</head>
<body>
<?php include '../inc/header.php'; ?>

    <!-- Main-content -->
    <section class="banner inner-banner">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-8 m-auto">
            <h1 class="sec-heading"> <span class="underline-text-color"></span> <span class="underline-text-color">Get A </span> Quote</h1>
          </div>
        </div>
      </div>
    </section>
    <!-- Main-content -->
    <!-- About -->
    <section class="locations qoute">
      <div class="container">
        <div class="row">
          <div class="col-lg-5 dis-flex-start">
            <div class="content">
              <h1 class="sec-heading mb-5"><span class="underline-text-color">LETS </span> WORK TOGETHER</h1>
              <ul class="list-unstyled">
                <li class="list-inline-item"><img src="/assets/images/app-futura.png" class="img-fluid"></li>
                <li class="list-inline-item"><img src="/assets/images/best-digital-agency.png" class="img-fluid"></li>
                <li class="list-inline-item"><img src="/assets/images/clutch-react.png" class="img-fluid"></li>
                <li class="list-inline-item"><img src="/assets/images/clutch.png" class="img-fluid"></li>
                <li class="list-inline-item"><img src="/assets/images/goodfirms.png" class="img-fluid"></li>
                <li class="list-inline-item"><img src="/assets/images/softwareworld.png" class="img-fluid"></li>
             
              </ul>
            </div>
          </div>
          <div class="col-lg-7 dis-flex">
            <div class="form">
            <form action="">
              <div class="row">
                <div class="col-6">
                  <label for="FULL NAME">FULL NAME <span>*</span></label>
                  <input type="text" class="form-control" required>
                </div>
                <div class="col-6">
                  <label for="FULL NAME">LAST NAME <span>*</span></label>
                  <input type="text" class="form-control" required>
                </div>
                <div class="col-6">
                  <label for="EMAIL ">EMAIL <span>*</span></label>
                  <input type="email" class="form-control" required >
                </div>
                <div class="col-6">
                  <label for="PHONE ">PHONE <span>*</span></label>
                  <input type="tel" class="form-control"  required>
                </div>
                <div class="col-12">
                  <label for="SERVICE ">SELECT SERVICE: <span>*</span></label>
                    <select name="" id="">
                      <option selected="">Website Design & Development</option>
                      <option> Mobile App Development</option>
                      <option> Ecommerce Solution</option>
                      <option> Branding</option>
                      <option> Digital Marketing</option>
                      <option> Social Media Marketing</option>
                    </select>
                </div>
                <div class="col-12">
                  <label for="Project ">PROJECT BUDGET: <span>*</span></label>
                  <input type="number" class="form-control"  required>
                </div>
                
                <div class="col-12">
                  <label for="HOW CAN WE HELP? ">PLEASE DESCRIBE YOUR PROJECT<span>*</span></label>
                  <textarea name="" id="" cols="" rows="5" required></textarea>
                </div>
              </div>
              <button type="submit" class="btn btn-business">Submit</button>
            </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- About -->

    <!-- Testimonials -->
<section class="testimonials">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="content">
          <h2 class="hd">TESTIMONIALS & REVIEWS</h2>
          <h1 class="sec-heading">What Our Valuable <span class="underline-text-color">Clients Say</span>.</h1>
        </div>
        <div id="testimonials">
          <div class="item">
            <div class="box">
              <p>“The app was successfully launched and fulfilled original expectations. The Designocracy team was communicative and effective in completing the project. The app is available in the Google Play store, and we’re thrilled with the final product. They were a highly efficient team to work with. They were strong communicators—whenever I had an issue they were available. Additionally, they were timely in getting deliverables to us.”</p>
              <div class="media">
                <img src="/assets/images/tom-asare-taxiappuk.jpg" class="img-fluid" alt="">
                <div class="media-body">
                  <h3> TOM ASARE <span>TAXIAPP UK</span></h3>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <p>“Designocracy continually went above and beyond the requirements of the project, developing a remarkably robust and functional platform. By handling any issues promptly, the team proved their excellent project management and communication skills. I can’t even explain with how impressed I am now working with them. I would have been satisfied if they had delivered what they had sold me, but this service goes above and beyond. What was very unique about Designocracy is how they make sure the milestones aren’t missed. I guess that goes along with why I’m so satisfied with their service.”</p>
              <div class="media">
                <img src="/assets/images/marc-chambers-rezieo.jpg" class="img-fluid" alt="">
                <div class="media-body">
                  <h3> MARC CHAMBERS<span>REZIEO</span></h3>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <p>“I used Designocracy to do all of the wireframing and development of the app. The project was all about developing a full app from wireframe to release on the app store. I came in with the ideas and requirements and they took that and translated that into the full creation. This project created a business. Without it, there would be no product to sell! I had a main point of contact who did all of the requirements gathering and overall project management coordination. It worked very well. The thing that was the most impressive for me was that they weren’t just blindly following directions.”</p>
              <div class="media">
                <img src="/assets/images/tom-asare-taxiappuk.jpg" class="img-fluid" alt="">
                <div class="media-body">
                  <h3> ALEX CORSTORPHINE<span> REPOSIT</span></h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Testimonials -->
    <!-- Featured Logo -->
    <section class="f_logo">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <h3 style="text-align: center;">Featured In:</h3>
            <div id="f_logo">
              <div class="item"><div class="img-box"><img src="/assets/images/11.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/22.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/33.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/44.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/55.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/66.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/77.png" class="img-fluid" alt=""></div></div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Featured Logo -->
    
 <!-- Footer -->
<?php include '../inc/footer.php'; ?>
<?php include '../inc/footer_script.php'; ?>
<!-- Footer -->