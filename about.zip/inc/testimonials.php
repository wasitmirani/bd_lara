<section class="testimonials">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="content">
          <h2 class="hd">TESTIMONIALS & REVIEWS</h2>
          <h1 class="sec-heading">What Our Valuable <span class="underline-text-color">Clients Say</span>.</h1>
        </div>
        <div id="testimonials">
          <div class="item">
            <div class="box">
              <p>“The app was successfully launched and fulfilled original expectations. The Digital Iconix team was communicative and effective in completing the project. The app is available in the Google Play store, and we’re thrilled with the final product. They were a highly efficient team to work with. They were strong communicators—whenever I had an issue they were available. Additionally, they were timely in getting deliverables to us.”</p>
              <div class="media">
                <img src="/assets/images/tom-asare-taxiappuk.jpg" class="img-fluid" alt="">
                <div class="media-body">
                  <h3> TOM ASARE <span>TAXIAPP UK</span></h3>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <p>“Digital Iconix continually went above and beyond the requirements of the project, developing a remarkably robust and functional platform. By handling any issues promptly, the team proved their excellent project management and communication skills. I can’t even explain with how impressed I am now working with them. I would have been satisfied if they had delivered what they had sold me, but this service goes above and beyond. What was very unique about Digital Iconix is how they make sure the milestones aren’t missed. I guess that goes along with why I’m so satisfied with their service.”</p>
              <div class="media">
                <img src="/assets/images/marc-chambers-rezieo.jpg" class="img-fluid" alt="">
                <div class="media-body">
                  <h3> MARC CHAMBERS<span>REZIEO</span></h3>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <p>“I used Digital Iconix to do all of the wireframing and development of the app. The project was all about developing a full app from wireframe to release on the app store. I came in with the ideas and requirements and they took that and translated that into the full creation. This project created a business. Without it, there would be no product to sell! I had a main point of contact who did all of the requirements gathering and overall project management coordination. It worked very well. The thing that was the most impressive for me was that they weren’t just blindly following directions.”</p>
              <div class="media">
                <img src="/assets/images/tom-asare-taxiappuk.jpg" class="img-fluid" alt="">
                <div class="media-body">
                  <h3> ALEX CORSTORPHINE<span> REPOSIT</span></h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>