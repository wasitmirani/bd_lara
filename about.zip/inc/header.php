<header class="header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-xs-12 col-md-12 col-md-12 col-lg-12">
        <nav class="navbar navbar-expand-lg navbar-light ">
          <div class="container-fluid">
            <a class="navbar-brand" href="/">
              <div class="logo">
                <img src="/assets/images/diwhitelogo.png" class="img-fluid" alt="">
              </div>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse menu " id="navbarSupportedContent">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
                <li class="list-inline-item nav-item"><a class="nav-link" href="/">Home</a></li>
                <li class="list-inline-item nav-item"><a class="nav-link" href="/about/">About us</a></li>
                <li class="list-inline-item nav-item"><a class="nav-link" href="/services/">Services</a></li>
                <li class="list-inline-item nav-item"><a class="nav-link" href="/">Portfolio</a></li>
                <li class="list-inline-item nav-item"><a class="nav-link" href="/contact/">Contact us</a></li>
                <li class="list-inline-item nav-item"><a class="nav-link qoute" href="/get-a-quote/" class="btn btn-business">GET A FREE QUOTE</a></li>
                <!-- <li class="list-inline-item nav-item"><a class="nav-link" href="#"><i class="fas fa-search"></i></a></li> -->
                
              </ul>
            </div>
          </div>
        </nav>
      </div>
    </div>
  </div>
</header>