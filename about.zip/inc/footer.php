<footer>
  <div class="container">
    <div class="row">
      <div class="col-lg-3">
        <h3>USA</h3>
        <ul class="list-unstyled menus">
          <li><a href="tel:(832) 956-0032">(832) 956-0032</a></li>
          <li><a target="_blank" href="https://goo.gl/maps/Srstz7Wd5r2CHxGZ9">15500 Voss Road, Suite 230D Sugar Land, TX 77498</a></li>
        </ul>
      </div>
      <div class="col-lg-3">
        <h3>TORONTO, ON</h3>
        <ul class="list-unstyled menus">
          <li><a href="#">647 642 7299</a></li>
          <li><a href="#">170 Clearbrooke Cir, Etobicoke,</a></li>
          <li><a href="#">ON M9W 2G1</a></li>
        </ul>
      </div>
      <div class="col-lg-3">
        <h3>DUBAI, UAE</h3>
        <ul class="list-unstyled menus">
          <li><a href="#">+971 50 234 0318</a></li>
          <li><a href="#">Office no. 102, Metropolis Tower Business Bay</a></li>
          <li><a href="#">Dubai , UAE</a></li>
        </ul>
      </div>
      <div class="col-lg-3">
        <h3>KARACHI, PAKISTAN</h3>
        <ul class="list-unstyled menus">
          <li><a href="#">+92 345 215 1273</a></li>
          <li><a href="#">U-172, P.E.C.H.S, Block: 2.</a></li>
          <li><a href="#">Tariq Rd, Karachi</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="copyright">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <p>© 2020 - All rights reserved by <strong>Digital Iconix</strong>.</p>
        </div>
        <div class="col-lg-6">
          <div class="social">
            <ul class="list-unstyled">
              <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
              <li><a href="#"><i class="fab fa-twitter"></i></a></li>
              <li><a href="#"><i class="fab fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>