<a id="button"></a>
<!-- Optional JavaScript; choose one of the two! -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script src="/assets/js/custom.js"></script>
<script src="/assets/slick-slider/slick/slick.min.js"></script>
<!-- <script src="assets/bootstrap-4/js/bootstrap.min.js"></script> -->
<!-- Option 1: Bootstrap Bundle with Popper -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script> -->
<script>
$(function () {
var shrinkHeader = 300;
$(window).scroll(function () {
var scroll = getCurrentScroll();
if (scroll >= shrinkHeader) {
$(".header").addClass("shrink");
} else {
$(".header").removeClass("shrink");
}
});
function getCurrentScroll() {
return window.pageYOffset || document.documentElement.scrollTop;
}
});
</script>
</body>
</html>