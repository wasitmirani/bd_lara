<?php include 'inc/meta.php'; ?>
<title>Digital Iconix | Home</title>
</head>
<body>
<?php include 'inc/header.php'; ?>
<!-- Main-content -->
<section class="banner">
  <div class="container-fluid">
    <div class="row">
      <div class="col-xm-5 col-sm-5 col-md-5 col-lg-5 first">
        <h1 style="color: #fff; transform: rotate(-90deg); font-size: 130px;">We <i class="fa fa-heart" style="color: #ffcc00;"></i><br> Digital</h1>
      </div>
      <div class="col-xm-7 col-sm-7 col-md-7 col-lg-7 second">
        <div class="content">
          <h1 class="sec-heading">We <span class="underline-text-color">create</span> &amp; <span class="underline-text-color">simplify</span> — brands, ecommerce and digital products</h1>
          <p>We help startups, mid-level and enterprise businesses grow, launch products and gain a competitive advantage in today’s digital-led world.</p>
          <a href="#" class="btn btn-business">Talk to us</a>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Main-content -->
<!-- Craft section -->
<section class="craft">
  <div class="container-fluid ">
    <div class="row">
      <div class="col-lg-12">
        <div class="content">
          <h2 class="hd">WE CRAFT</h2>
          <h1 class="sec-heading">Unique, truly responsive and functional products <span class="underline-text-color">that impress</span>.</h1>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12 col-md-6 col-lg-4 p-0">
        <div class="box">
          <i class="fas fa-laptop"></i>
          <h3>Website Design<span class="accent-color">.</span></h3>
          <p>We have experts to help you achieve your business goals & gain a competitive edge with a stunning & feature-rich website.</p>
        </div>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-4 p-0">
        <div class="box">
          <i class="fas fa-mobile-alt"></i>
          <h3> MOBILE APPS<span class="accent-color">.</span></h3>
          <p>We live and breathe mobile. Our award-winning approach lets us design, deliver and support world-class, high-performance native solutions for iOS and Android.</p>
        </div>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-4 p-0">
        <div class="box">
          <i class="fas fa-cash-register"></i>
          <h3> ECOMMERCE SOLUTIONS<span class="accent-color">.</span></h3>
          <p>We provide complete ecommerce solutions as per your needs that gives you guaranteed beneficial results for your online business.</p>
        </div>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-4 p-0">
        <div class="box">
          <i class="fas fa-pencil-alt"></i>
          <h3> BRANDING<span class="accent-color">.</span></h3>
          <p>Your brand is the most expensive asset of your company which we build with valuable branding techniques.</p>
        </div>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-4 p-0">
        <div class="box">
          <i class="fas fa-volume-up"></i>
          <h3> DIGITAL MARKETING<span class="accent-color">.</span></h3>
          <p>We study your business and come up with a digital marketing strategy that will do wonders for you, both in short and long term.</p>
        </div>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-4 p-0">
        <div class="box">
          <i class="fas fa-globe"></i>
          <h3> SOCIAL MEDIA<span class="accent-color">.</span></h3>
          <p>Social media management made easy. Engage your customers and grow your business. We take the guesswork out of social media marketing.</p>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Craft section -->
<!-- IDEAS -->
<section class="ideas">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-12 col-md-12 col-lg-6 p-0 dis-flex">
        <div class="content">
          <h2 class="sec-heading">We love transforming product ideas to <span class="underline-text-color">digital realities.</span></h2>
          <p>Digital Iconix is a leading digital agency dedicated to providing businesses with reliable technological solutions. We have helped countless entrepreneurs achieve their goals and drive results by creating top rated mobile apps and websites.</p>
          <p>As a global company, our aim isn’t just to create digital solutions but to help businesses achieve sustainable growth and scalability. Our teams and networks stretch across the United States with offices in Buffalo, NY & Dover, DE and have extended its reach to regions of the Middle East.</p>
          <a href="#" class="btn btn-business">Talk to us</a>
        </div>
      </div>
      <div class="col-sm-12 col-md-12 col-lg-6">
        <div class="row">
          <div class="col-sm-12 col-md-6 col-lg-6 pr-0 pl-0">
            <div class="img-box"><img src="assets/images/8years.jpg" class="img-fluid w-100" alt=""></div>
          </div>
          <div class="col-sm-12 col-md-6 col-lg-6 pl-0 pr-0">
            <div class="img-box"><img src="assets/images/4locations.jpg" class="img-fluid w-100" alt=""></div>
          </div>
          <div class="col-sm-12 col-md-6 col-lg-6 pr-0 pl-0">
            <div class="img-box"><img src="assets/images/6unites.jpg" class="img-fluid w-100" alt=""></div>
          </div>
          <div class="col-sm-12 col-md-6 col-lg-6 pl-0 pr-0">
            <div class="img-box"><img src="assets/images/1minteractions.jpg " class="img-fluid w-100" alt=""></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- IDEAS -->
<!-- Logos -->
<section class="logos">
  <div class="container ">
    <div class="row">
      <div class="col-lg-12">
        <div class="content">
          <h2 class="hd">OUR ACHIEVEMENTS</h2>
          <h1 class="sec-heading"><span class="underline-text-color">Awards &amp; Recognitions</span> over the years</h1>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-6 col-md-4 col-lg-2"><div class="img-box"><img src="assets/images/app-futura.png" class="img-fluid" alt=""></div></div>
      <div class="col-sm-6 col-md-4 col-lg-2"><div class="img-box"><img src="assets/images/best-digital-agency.png" class="img-fluid" alt=""></div></div>
      <div class="col-sm-6 col-md-4 col-lg-2"><div class="img-box"><img src="assets/images/clutch-react.png" class="img-fluid" alt=""></div></div>
      <div class="col-sm-6 col-md-4 col-lg-2"><div class="img-box"><img src="assets/images/clutch.png" class="img-fluid" alt=""></div></div>
      <div class="col-sm-6 col-md-4 col-lg-2"><div class="img-box"><img src="assets/images/goodfirms.png" class="img-fluid" alt=""></div></div>
      <div class="col-sm-6 col-md-4 col-lg-2"><div class="img-box"><img src="assets/images/softwareworld.png" class="img-fluid" alt=""></div></div>
    </div>
  </div>
</section>
<!-- Logos -->
<!-- Counter -->
<section class="counter">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-6 col-lg-3 dis-flex">
        <h2 class="sec-heading">200+ <strong class="hd"> Satisfied Customers</strong></h2>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-3 dis-flex">
        <h2 class="sec-heading">150+ <strong class="hd">Projects Delivered</strong></h2>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-3 dis-flex">
        <h2 class="sec-heading">87% <strong class="hd">Repeated Business</strong></h2>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-3 dis-flex">
        <h2 class="sec-heading">170 <strong class="hd"> Positive Reviews</strong></h2>
      </div>
    </div>
  </div>
</section>
<!-- Counter -->
<!-- Projects -->
<section class="project">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="content">
          <h2 class="hd">WHAT WE DO</h2>
          <h1 class="sec-heading">Discover our <span class="underline-text-color">featured projects</span> of&nbsp;the&nbsp;year.</h1>
          <p>Digital Iconix provides businesses of all levels and backgrounds, experiences that can help propel their ideas forward. We’re here to connect them with world changing thinkers and leaders in the industry, and help reignite their passion for the visual.</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12 col-md-6 col-lg-4">
        <a href="#">
          <div class="img-box"><img src="assets/images/amplifund-header.jpg" class="img-fluid" alt=""></div>
        </a>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-4">
        <a href="#">
          <div class="img-box"><img src="assets/images/vividseats-header.jpg" class="img-fluid" alt=""></div>
        </a>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-4">
        <a href="#">
          <div class="img-box"><img src="assets/images/labayh-header.jpg" class="img-fluid" alt=""></div>
        </a>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-4">
        <a href="#">
          <div class="img-box"><img src="assets/images/instafresh-header.jpg" class="img-fluid" alt=""></div>
        </a>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-4">
        <a href="#">
          <div class="img-box"><img src="assets/images/assetlyst-header.jpg" class="img-fluid" alt=""></div>
        </a>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-4">
        <a href="#">
          <div class="img-box"><img src="assets/images/ourphotographer-header.jpg" class="img-fluid" alt=""></div>
        </a>
      </div>
      <a href="#" class="btn btn-main"> View More</a>
    </div>
  </div>
</section>
<!-- Projects -->
<!-- Testimonials -->
<?php include 'inc/testimonials.php'; ?>
<!-- Testimonials -->
<!-- Quote -->
<section class="quote">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="content">
          <h2 style="text-align: center; color: #fff; ">Need help with your project? <a style="border-bottom: 3px solid #ffcc00; color: #ffcc00;" href="#">Lets Talk!</a></h2>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Quote -->
<!-- Brands -->
<section class="brands">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="content">
          <h2 class="hd">Our Subsidiaries</h2>
          <h1 class="sec-heading">Our <span class="underline-text-color">Subsidiaries</span> </h1>
          <p>Being a leading web, mobile, and enterprise services provider, we have delivered our effective solutions to various brands like:</p>
        </div>
      </div>
    </div>
    <div class="row justify-content-center">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-4"><div class="img-box"><a target="_blank" href="https://websiteiconix.com/"><img src="assets/images/WI.png" class="img-fluid w-50" alt=""></a></div></div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-4"><div class="img-box"><a target="_blank" href="https://animationiconix.com/"><img src="assets/images/AI.png" class="img-fluid w-50" alt=""></a></div></div>
    </div>
  </div>
</section>
<!-- Brands -->
<!-- Featured Logo -->
<section class="f_logo">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h3 style="text-align: center;">Featured In:</h3>
        <div id="f_logo">
          <div class="item"><div class="img-box"><img src="assets/images/11.png" class="img-fluid" alt=""></div></div>
          <div class="item"><div class="img-box"><img src="assets/images/22.png" class="img-fluid" alt=""></div></div>
          <div class="item"><div class="img-box"><img src="assets/images/33.png" class="img-fluid" alt=""></div></div>
          <div class="item"><div class="img-box"><img src="assets/images/44.png" class="img-fluid" alt=""></div></div>
          <div class="item"><div class="img-box"><img src="assets/images/upwork.png" class="img-fluid" alt=""></div></div>
          <div class="item"><div class="img-box"><img src="assets/images/55.png" class="img-fluid" alt=""></div></div>
          <div class="item"><div class="img-box"><img src="assets/images/66.png" class="img-fluid" alt=""></div></div>
          <div class="item"><div class="img-box"><img src="assets/images/77.png" class="img-fluid" alt=""></div></div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Featured Logo -->
<!-- Turn IDeas -->
<section class="turn">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 p-0 first">
        <h2 class="hd">What We Do?</h2>
        <h2 class="sec-heading">Turn Ideas Into Digital Realities</h2>
      </div>
      <div class="col-lg-6 p-0 second">
        <h2 class="hd">SO WHAT’S NEXT?</h2>
        <h2 class="sec-heading">Let’s Work Together!</h2>
      </div>
    </div>
  </div>
</section>
<!-- Turn IDeas -->
<!-- Footer -->
<?php include 'inc/footer.php'; ?>
<?php include 'inc/footer_script.php'; ?>
<!-- Footer -->