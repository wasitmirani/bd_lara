<?php include '../inc/meta.php'; ?>
<title>Designocracy | Contact</title>
</head>
<body>
<?php include '../inc/header.php'; ?>

    <!-- Main-content -->
    <section class="banner inner-banner">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-8 m-auto">
            <h1 class="sec-heading"> <span class="underline-text-color"></span> <span class="underline-text-color">Contact </span> Us</h1>
          </div>
        </div>
      </div>
    </section>
    <!-- Main-content -->
    <!-- About -->
    <section class="locations">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 dis-flex-start">
            <div class="content">
              <h2 class="hd">Our Locations</h2>
              <h2 class="sec-heading"><span class="underline-text-color2">UNITED </span> STATES</h2>
              <ul class="list-unstyled">
                <li><a href="tel:(832) 956-0032"><strong>(832) 956-0032</strong></a></li>
                <li><a href="mailto:hello@digitaliconix.com"><strong>hello@digitaliconix.com</strong></a></li>
                <li><a href="#map"><strong>15500 Voss Road, Suite 230D Sugar Land, TX 77498</strong></a></li>
              </ul>
              
            </div>
          </div>
          <div class="col-lg-6 dis-flex">
            <div class="img-box"><img src="/assets/images/mobile-apps.png" class="img-fluid" alt=""></div>
          </div>
        </div>
      </div>
    </section>
    <!-- About -->
    <!-- Contact Form -->
    <section class="form">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 m-auto">
            <h1 class="sec-heading mb-5"><span class="underline-text-color">LETS </span> WORK TOGETHER</h1>
            <form action="">
              <div class="row">
                <div class="col-12">
                  <label for="FULL NAME">FULL NAME <span>*</span></label>
                  <input type="text" class="form-control" required>
                </div>
                <div class="col-6">
                  <label for="EMAIL ">EMAIL <span>*</span></label>
                  <input type="email" class="form-control" required >
                </div>
                <div class="col-6">
                  <label for="PHONE ">PHONE <span>*</span></label>
                  <input type="text" class="form-control"  required>
                </div>
                <div class="col-12">
                  <label for="HOW CAN WE HELP? ">HOW CAN WE HELP? <span>*</span></label>
                  <textarea name="" id="" cols="" rows="5" required></textarea>
                </div>
              </div>
              <button type="submit" class="btn btn-business">Submit</button>
            </form>
          </div>
        </div>
      </div>
    </section>
    <!-- Contact Form -->
    <!-- MAp -->
    <section class="map" id="map">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3467.5731694369256!2d-95.65929138489422!3d29.645137782029362!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8640e0b83d112ef1%3A0x1565504221fe9c40!2s15500%20Voss%20Rd%20%23230d%2C%20Sugar%20Land%2C%20TX%2077498%2C%20USA!5e0!3m2!1sen!2s!4v1626384758848!5m2!1sen!2s" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
          </div>
        </div>
      </div>
    </section>
    <!-- MAp -->
    
    <!-- Logos -->
    <section class="logos">
      <div class="container ">
        <div class="row">
          <div class="col-lg-12">
            <div class="content">
              <h2 class="hd">OUR ACHIEVEMENTS</h2>
              <h1 class="sec-heading"><span class="underline-text-color">Awards &amp; Recognitions</span> over the years</h1>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-2"><div class="img-box"><img src="/assets/images/app-futura.png" class="img-fluid" alt=""></div></div>
          <div class="col-lg-2"><div class="img-box"><img src="/assets/images/best-digital-agency.png" class="img-fluid" alt=""></div></div>
          <div class="col-lg-2"><div class="img-box"><img src="/assets/images/clutch-react.png" class="img-fluid" alt=""></div></div>
          <div class="col-lg-2"><div class="img-box"><img src="/assets/images/clutch.png" class="img-fluid" alt=""></div></div>
          <div class="col-lg-2"><div class="img-box"><img src="/assets/images/goodfirms.png" class="img-fluid" alt=""></div></div>
          <div class="col-lg-2"><div class="img-box"><img src="/assets/images/softwareworld.png" class="img-fluid" alt=""></div></div>
        </div>
      </div>
    </section>
    <!-- Logos -->
    
    <!-- Featured Logo -->
    <section class="f_logo">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <h3 style="text-align: center;">Featured In:</h3>
            <div id="f_logo">
              <div class="item"><div class="img-box"><img src="/assets/images/11.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/22.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/33.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/44.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/upwork.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/55.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/66.png" class="img-fluid" alt=""></div></div>
              <div class="item"><div class="img-box"><img src="/assets/images/77.png" class="img-fluid" alt=""></div></div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Featured Logo -->
    
 <!-- Footer -->
<?php include '../inc/footer.php'; ?>
<?php include '../inc/footer_script.php'; ?>
<!-- Footer -->