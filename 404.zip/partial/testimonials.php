<section class="testimonial sec-before">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="heading-two">Great creative agency find ways for their team to support then</h2>
			</div>
		</div>
		<div id="testimonials">
			<div class="item">
				<div class="box">
					<div class="media">
						<div class="img-box"><img src="/assets/images/testimonial-girl-img2.jpg" alt=""></div>
						<div class="media-body">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
							dolore eu fugiat nulla pariatur.</p>
							<strong>Sara smith</strong>
							<span>Creative DX</span>
						</div>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="box">
					<div class="media">
						<div class="img-box"><img src="/assets/images/testimonial-girl-img.jpg" alt=""></div>
						<div class="media-body">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
							dolore eu fugiat nulla pariatur.</p>
							<strong>Sara smith</strong>
							<span>Creative DX</span>
						</div>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="box">
					<div class="media">
						<div class="img-box"><img src="/assets/images/testimonial-man-img.jpg" alt=""></div>
						<div class="media-body">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
							dolore eu fugiat nulla pariatur.</p>
							<strong>Sara smith</strong>
							<span>Creative DX</span>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
</section>