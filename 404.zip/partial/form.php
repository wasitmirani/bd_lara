<section class="work mn-hd">
   <div class="container">
      <div class="row">
         <div class="col-md-6">
            <h2 class="heading-two wow fadeInUp animated" data-wow-delay="0.2s">Your Website Design Is Just A Form Away</h2>
            <div class="usrimg wow fadeInUp animated" data-wow-delay="0.4s">
               
            </div>
            <div class="usercon wow fadeInUp animated" data-wow-delay="0.6s">
               <h6>Fill-up the order form to get started with your <br>custom logo design order at Logo Design <br>Profs rightaway.</h6>
            </div>
         </div>
         <div class="col-md-6">
            <div class="banform">
               <h5 class="text-center">Sign up to get your Custom <br>made Logo Design</h5>
               <form action="crm/include/offercontact.html" method="GET">
                  <div class="banfield">
                     <input type="text" required="" placeholder="Full Name" name="popupname">
                  </div>
                  <div class="banfield">
                     <input type="email" required="" placeholder="Email Address" name="popupemail" >
                  </div>
                  <div class="banfield">
                     <input type="tel" required="" placeholder="Phone Number" name="phone">
                     <input type="hidden" name="leadsource" value="logo-design-offer3">
                  </div>
                  <div class="banfield">
                     <input type="text" placeholder="Business Name">
                  </div>
                  <div class="banfield">
                     <input type="submit" value="get started now">
                     <!-- <button>get started now</button> -->
                  </div>
               </form>
               <p class="text-center">You'll fill your logo brief next</p>
            </div>
         </div>
      </div>
   </div>
</section>