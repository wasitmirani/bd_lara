<section class="portfolio sec-before">
	<div class="container">
		<div class="row text-center">
			<h2 class="hd">Featured Projects</h2>
			<h2 class="heading-one">Work that makes us proud and happy</h2>
		</div>
		<div class="row">
			<div class="port col-12 col-sm-3 col-md-4 col-lg-4">
				<div class="img-box">
					<a href="/assets/images/project-1.jpg" data-fancybox="logotab">
						<img src="/assets/images/project-1.jpg" class="img-fluid" alt="">
						<div class="overlay-portfolio">
							<i class="fas fa-search-plus mb-2"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="port col-12 col-sm-3 col-md-4 col-lg-4">
				<div class="img-box">
					<a href="/assets/images/project-2.jpg" data-fancybox="logotab">
						<img src="/assets/images/project-2.jpg" class="img-fluid" alt="">
						<div class="overlay-portfolio">
							<i class="fas fa-search-plus mb-2"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="port col-12 col-sm-3 col-md-4 col-lg-4">
				<div class="img-box">
					<a href="/assets/images/project-3.jpg" data-fancybox="logotab">
						<img src="/assets/images/project-3.jpg" class="img-fluid" alt="">
						<div class="overlay-portfolio">
							<i class="fas fa-search-plus mb-2"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="port col-12 col-sm-3 col-md-4 col-lg-4">
				<div class="img-box">
					<a href="/assets/images/project-4.jpg" data-fancybox="logotab">
						<img src="/assets/images/project-4.jpg" class="img-fluid" alt="">
						<div class="overlay-portfolio">
							<i class="fas fa-search-plus mb-2"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="port col-12 col-sm-3 col-md-4 col-lg-4">
				<div class="img-box">
					<a href="/assets/images/project-5.jpg" data-fancybox="logotab">
						<img src="/assets/images/project-5.jpg" class="img-fluid" alt="">
						<div class="overlay-portfolio">
							<i class="fas fa-search-plus mb-2"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="port col-12 col-sm-3 col-md-4 col-lg-4">
				<div class="img-box">
					<a href="/assets/images/project-6.jpg" data-fancybox="logotab">
						<img src="/assets/images/project-6.jpg" class="img-fluid" alt="">
						<div class="overlay-portfolio">
							<i class="fas fa-search-plus mb-2"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="port col-12 col-sm-3 col-md-4 col-lg-4">
				<div class="img-box">
					<a href="/assets/images/project-7.jpg" data-fancybox="logotab">
						<img src="/assets/images/project-7.jpg" class="img-fluid" alt="">
						<div class="overlay-portfolio">
							<i class="fas fa-search-plus mb-2"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="port col-12 col-sm-3 col-md-4 col-lg-4">
				<div class="img-box">
					<a href="/assets/images/project-8.jpg" data-fancybox="logotab">
						<img src="/assets/images/project-8.jpg" class="img-fluid" alt="">
						<div class="overlay-portfolio">
							<i class="fas fa-search-plus mb-2"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="port col-12 col-sm-3 col-md-4 col-lg-4">
				<div class="img-box">
					<a href="/assets/images/project-9.jpg" data-fancybox="logotab">
						<img src="/assets/images/project-9.jpg" class="img-fluid" alt="">
						<div class="overlay-portfolio">
							<i class="fas fa-search-plus mb-2"></i>
						</div>
					</a>
				</div>
			</div>
		</div>
		<div class="row text-center">
			<div class="btn-span m-auto"><a href="/" class="btn bg btn-smart">Our Portfolio</a></div>
		</div>
	</div>
</section>