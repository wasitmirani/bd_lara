<!-- Meta -->
<?php include '../partial/meta.php'; ?>
<!-- Meta -->
<title>Web Development Pros</title>
</head>
<body>
<!-- Header -->
<?php include '../partial/header.php'; ?>
<!-- Header -->
		<!-- Main Banner -->
		<section class="contact-banner">
			<div class="container">
				<div class="row">
					<div class="col-lg-5">
						<h2 class="heading-one arrow-hd">Get in touch</h2>
						<div class="row">
							<div class="col-lg-6">
								<div class="contact">
									<h6>Work Inquiries <strong>+1.000.123.3456</strong></h6>
									<ul class="list-unstyled m-0">
										<li>Assistance hours:</li>
										<li>Monday – Friday</li>
										<li>6 am to 8 pm EST</li>
									</ul>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="contact">
									<h6>Careers & Press <strong>+1.000.123.3456</strong></h6>
									<ul class="list-unstyled m-0">
										<li>Assistance hours:</li>
										<li>Monday – Friday</li>
										<li>6 am to 8 pm EST</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-7">
						<div class="row">
							<div class="col-lg-5">
								<h6><strong>Post address</strong></h6>
								<ul class="list-unstyled m-0">
									<li>Area 51 Melville Ave, Palo Alto, <br> CA 94301, <br> United States</li>
								</ul>
								<h6><strong>Social Media</strong></h6>
								<ul class="list-unstyled m-0">
									<li><a href="#">Facebook</a></li>
									<li><a href="#">Instagram</a></li>
									<li><a href="#">Twitter</a></li>
								</ul>
							</div>
							<div class="col-lg-7">
								<div class="img-box"><img src="assets/images/contact/banner-side-img.png" class="img-fluid" alt=""></div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<div class="map">
							<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13004069.896900944!2d-104.65611544442767!3d37.27565371492453!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54eab584e432360b%3A0x1c3bb99243deb742!2sUnited%20States!5e0!3m2!1sen!2s!4v1614809590281!5m2!1sen!2s" width="100%" height="auto" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Main Banner -->
<!-- Contact Form -->
<?php include '../partial/form.php'; ?>
<!-- Contact Form -->
<!-- Footer -->
<?php include '../partial/footer.php'; ?>
<!-- Footer -->
<!-- Footer Script -->
<?php include '../partial/footer_script.php'; ?>
<!-- Footer Script -->