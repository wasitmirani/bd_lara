<!-- Meta -->
<?php include '../partial/meta.php'; ?>
<!-- Meta -->
<title>Web Development Pros - CMS</title>
</head>
<body>
<!-- Header -->
<?php include '../partial/header.php'; ?>
<!-- Header -->
<!-- Main Banner -->
<section class="banner banner-in">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-6 col-lg-6 dis-flex">
				<h1 class="heading-two">Maintain Your Websites
				Professionally With Our CMS.</h1>
				<p class="para-one">Creating top-class websites, mobile apps and
				brand identity</p>
				<ul class="list-unstyled">
					<li class="list-inline-item mr-4"><div class="btn-span"><a href="/" class="btn bg btn-smart">Let’s Talk</a></div></li>
					<li class="list-inline-item"><a href="#" class="btn btn-simple">Explore More</a></li>
				</ul>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-6">
				<div class="img-box cirlce-in">
					<img src="/assets/images/cms/cms-banner-img.jpg" class="img-fluid" alt="">
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Main Banner -->
<!-- Logos One -->
<section class="logos-one">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12 col-lg-12">
				<div class="img-box">
					<img src="/assets/images/logos-img.jpg" class="img-fluid" alt="">
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Logos One -->
<!-- B2B Opportunities -->
<section class="opportunities">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="heading-two arrow-hd text-center text-grad font-med mb6">Tailor your content with ease using WDP. CMS web development</h2>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-4">
				<div class="box m2">
					<div class="img-box"><img src="/assets/images/cms/icon-1.png" class="img-fluid" alt=""></div>
					<h2 class="heading-four">WYSIWYG Editor</h2>
					<p class="para-two">Add, delete, edit or modify the text and images, and videos to improve the look and feel of the website.</p>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="box m2">
					<div class="img-box"><img src="/assets/images/cms/icon-2.png" class="img-fluid" alt=""></div>
					<h2 class="heading-four"> Admin Control Management</h2>
					<p class="para-two"> Add, delete, edit or modify the text and images, and videos to improve the look and feel of the website.</p>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="box m2">
					<div class="img-box"><img src="/assets/images/cms/icon-3.png" class="img-fluid" alt=""></div>
					<h2 class="heading-four">Cost Effective </h2>
					<p class="para-two">Add, delete, edit or modify the text and images, and videos to improve the look and feel of the website. </p>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="box m2">
					<div class="img-box"><img src="/assets/images/cms/icon-4.png" class="img-fluid" alt=""></div>
					<h2 class="heading-four">Website Easily Manageable </h2>
					<p class="para-two">Add, delete, edit or modify the text and images, and videos to improve the look and feel of the website. </p>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="box m2">
					<div class="img-box"><img src="/assets/images/cms/icon-5.png" class="img-fluid" alt=""></div>
					<h2 class="heading-four"> Social Media Integrations</h2>
					<p class="para-two">Add, delete, edit or modify the text and images, and videos to improve the look and feel of the website. </p>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="box m2">
					<div class="img-box"><img src="/assets/images/cms/icon-6.png" class="img-fluid" alt=""></div>
					<h2 class="heading-four">SEO Friendly </h2>
					<p class="para-two">Add, delete, edit or modify the text and images, and videos to improve the look and feel of the website. </p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- B2B Opportunities -->
<!-- Website Services -->
<section class="web-service">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="heading-two text-center mb6">Take a leap and explore new opportunities with our B2B and B2C portals</h2>
			</div>
			<div class="row">
				<div class="col-lg-6">
					<div class="img-box"><img src="/assets/images/b2b/type-img.jpg" class="img-fluid" alt=""></div>
				</div>
				<div class="col-lg-6 dis-flex">
					<h2 class="heading-three style-li">CMS based Websites</h2>
					<p class="para-two">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.
					</p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Website Services -->
<!-- Portfolio -->
<?php include '../partial/portfolio.php'; ?>
<!-- Portfolio -->
<!-- Brief -->
<section class="brief">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-6 col-lg-3">
				<div class="box">
					<h2 class="text-grad mb5">01</h2>
					<h2 class="heading-four">Design
					Brief </h2>
					<p class="para-two"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspen.</p>
				</div>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-3">
				<div class="box">
					<h2 class="text-grad mb5">02</h2>
					<h2 class="heading-four">Brainstorming
					Conceptualization</h2>
					<p class="para-two"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspen.</p>
				</div>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-3">
				<div class="box">
					<h2 class="text-grad mb5">03</h2>
					<h2 class="heading-four">Revisions /
					Approval</h2>
					<p class="para-two"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspen.</p>
				</div>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-3">
				<div class="box">
					<h2 class="text-grad mb5">04</h2>
					<h2 class="heading-four">Final Delivery </h2>
					<p class="para-two"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspen.</p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Brief -->
<!-- Pricing -->
<?php include '../partial/pricing.php'; ?>
<!-- Pricing -->
<!-- Let's Talk -->
<section class="lets-talk">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="heading-three">We have Digital Solution for Everyone <strong>Let’s help you find more clients and grow your Business</strong></h2>
				<ul class="list-unstyled mb-0 mt-5">
					<li class="list-inline-item"><a href="#" class="btn btn-simple">Let’s Talk</a></li>
					<li class="list-inline-item"><a href="#" class="btn btn-simple">Let’s Get Started</a></li>
				</ul>
			</div>
		</div>
	</div>
</section>
<!-- Let's Talk -->
<!-- Testimonial -->
<?php include '../partial/testimonials.php'; ?>
<!-- Testimonial -->
<!-- Footer -->
<?php include '../partial/footer.php'; ?>
<!-- Footer -->
<!-- Footer Script -->
<?php include '../partial/footer_script.php'; ?>
<!-- Footer Script -->