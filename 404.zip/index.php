<!-- Meta -->
<?php include 'partial/meta.php'; ?>
<!-- Meta -->
<title>Web Development Pros - Home</title>
</head>
<body>
<!-- Header -->
<?php include 'partial/header.php'; ?>
<!-- Header -->
<!-- Main Banner -->
<section class="banner">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-6 col-lg-6 ">
				<h1 class="heading-one">Think the design, design the thinking.</h1>
				<p class="para-one">WDP Web Designs is a high-end, full-service digital design agency delivering seamless web design and development services.</p>
				<div class="btn-span"><a href="/" class="btn bg btn-smart">get a free quote</a></div>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-6">
				<div class="img-box ">
					<img src="/assets/images/banner-side-img.png" class="img-fluid" alt="">
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Main Banner -->
<!-- Logos One -->
<section class="logos-one">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12 col-lg-12">
				<div class="img-box">
					<img src="/assets/images/logos-img.jpg" class="img-fluid" alt="">
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Logos One -->
<!-- About -->
<section class="about">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-5 col-lg-5 ">
				<div class="img-box">
					<img src="/assets/images/about-img-2.jpg" class="img-fluid" alt="">
				</div>
			</div>
			<div class="col-sm-12 col-md-7 col-lg-7 back-color">
				<h2 class="heading-two">Maximize Success with Strategically Designed Content</h2>
				<p class="para-two">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.</p>
				<div class="row">
					<div class="col-sm-12 col-md-12 col-lg-6 dis-flex-start">
						<a href="#" class="btn btn-simple">Explore more</a>
					</div>
					<div class="col-sm-12 col-md-12 col-lg-6">
						<img src="/assets/images/about-logo.jpg" class="img-fluid" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- About -->
<!-- Portfolio -->
<?php include 'partial/portfolio.php'; ?>
<!-- Portfolio -->
<!-- Awards -->
<section class="awards sec-before ">
	<div class="container">
		<div class="row">
			<div class="col-12 col-sm-3 col-md-4 col-lg-4">
				<h2 class="heading-three">Ranked among one of the world’s best UX firms</h2>
			</div>
			<div class="col-12 col-sm-12 col-md-8 col-lg-8">
				<div class="img-box"><img src="/assets/images/partners.png" class="img-fluid" alt=""></div>
			</div>
		</div>
	</div>
</section>
<!-- Awards -->
<!-- Mission -->
<section class="mission">
	<div class="container">
		<div class="mission-in">
			<div class="row">
				<div class="col-12 col-sm-3 col-md-6 col-lg-6">
					<div class="img-box"><img src="/assets/images/mission-side-img.png" class="img-fluid" alt="">
					</div>
				</div>
				<div class="miss col-12 col-sm-12 col-md-6 col-lg-6">
					<p>As a full-service design agency,
						we work closely with our clients to define,
						design, and develop transformative user
						experiences across all platforms and
					brand’s touch points.</p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Mission -->
<!-- Proud Section -->
<section class="proud sec-before">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12 col-lg-12">
				<h2 class="heading-two">We are the proud developers of engaging web designs</h2>
				<p class="para-one"> interactive digital products, and competitive web-based branding strategies.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12 col-md-6 col-lg-3">
				<div class="box">
					<div class="img-box"><img src="/assets/images/service-icon-1.png" alt=""></div>
					<h2 class="heading-three">Static Website</h2>
					<ul class="list-unstyled">
						<li>Naming</li>
						<li>Logo design</li>
						<li>Brand identity system</li>
						<li>Marketing graphics</li>
					</ul>
				</div>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-3">
				<div class="box">
					<div class="img-box"><img src="/assets/images/service-icon-2.png" alt=""></div>
					<h2 class="heading-three">Ecommerce Website </h2>
					<ul class="list-unstyled">
						<li>Naming</li>
						<li>Logo design</li>
						<li>Brand identity system</li>
						<li>Marketing graphics</li>
					</ul>
				</div>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-3">
				<div class="box">
					<div class="img-box"><img src="/assets/images/service-icon-3.png" alt=""></div>
					<h2 class="heading-three">CMS Website</h2>
					<ul class="list-unstyled">
						<li>Naming</li>
						<li>Logo design</li>
						<li>Brand identity system</li>
						<li>Marketing graphics</li>
					</ul>
				</div>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-3">
				<div class="box">
					<div class="img-box"><img src="/assets/images/service-icon-4.png" alt=""></div>
					<h2 class="heading-three">B2B and B2C Portals </h2>
					<ul class="list-unstyled">
						<li>Naming</li>
						<li>Logo design</li>
						<li>Brand identity system</li>
						<li>Marketing graphics</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Proud Section -->
<!-- Testimonial -->
<?php include 'partial/testimonials.php'; ?>
<!-- Testimonial -->
<!-- Logos-3 -->
<!-- 		<section class="logos-3 p-5 bg-grey">
		<div class="container">
				<div class="row">
						<div class="col-lg-12 text-center">
								<div class="img-box"><img src="/assets/images/businesses.png" class="img-fluid" alt=""></div>
						</div>
				</div>
		</div>
</section> -->
<!-- Logos-3 -->
<!-- Contact Form -->
<?php include 'partial/form.php'; ?>
<!-- Contact Form -->
<!-- Footer -->
<?php include 'partial/footer.php'; ?>
<!-- Footer -->
<!-- Footer Script -->
<?php include 'partial/footer_script.php'; ?>
<!-- Footer Script -->