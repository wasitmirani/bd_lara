<!-- Meta -->
<?php include '../partial/meta.php'; ?>
<!-- Meta -->
<title>Web Development Pros - 404</title>
</head>
<body>
<!-- Header -->
<header>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
				<div class="logo">
					<a href="/"><img src="/assets/images/header-logo.png" class="img-fluid" alt=""></a>
				</div>
			</div>
		</div>
	</div>
</header>
<!-- Header -->

<!-- Main Banner -->
<section class="banner banner-in error sec-before">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-6 col-lg-6 dis-flex">
				<h1 class="heading-two text-grad">Never Existed.</h1>
				<p class="para-one">The page you are looking for was moved,  removed, renamed or might</p>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-6 dis-flex text-center">
				<div class="img-box cirlce-in">
					<img src="/assets/images/404.png" class="img-fluid" alt="">
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Main Banner -->

<!-- Footer Script -->
<?php include '../partial/footer_script.php'; ?>
<!-- Footer Script