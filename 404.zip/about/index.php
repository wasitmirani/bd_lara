<!-- Meta -->
<?php include '../partial/meta.php'; ?>
<!-- Meta -->
<title>Web Development Pros - About us</title>
</head>
<body>
<!-- Header -->
<?php include '../partial/header.php'; ?>
<!-- Header -->
<!-- Main Banner -->
<section class="banner-in">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-6 col-lg-6 ">
				<h1 class="heading-two">We make strategies, design & development to create valuable products.</h1>
				<ul class="list-unstyled mb-0 mt-4">
					<li class="list-inline-item mr-5"><img src="/assets/images/about/logo-1.png" alt=""></li>
					<li class="list-inline-item mr-5"><img src="/assets/images/about/logo-2.png" alt=""></li>
					<li class="list-inline-item"><img src="/assets/images/about/logo-3.png" alt=""></li>
				</ul>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-6">
				<p class="para-one">Founded and lead by serial entrepreneurs, we partner with ambitious leaders to design radically better online businesses.</p>
				<p class="para-two">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</p>
			</div>
		</div>
	</div>
</section>
<!-- Main Banner -->
<!-- About -->
<section class="about">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-5 col-lg-5 ">
				<div class="img-box">
					<img src="/assets/images/about/about-us-img.png" class="img-fluid" alt="">
				</div>
			</div>
			<div class="col-sm-12 col-md-7 col-lg-7 back-color">
				<h2 class="heading-two">We're a team of creatives who are excited about new ideas and unique mutual opportunities.</h2>
				<p class="para-two">Our clients describe us as a product team which creates <span class="color-pink">amazing UI/UX</span> experiences, by crafting top-notch user experience.</p>
				<div class="row">
					<div class="col-sm-12 col-md-12 col-lg-6 dis-flex-start">
						<ul class="list-unstyled">
							<li>- Art Direction</li>
							<li> - Brand Identities</li>
							<li> - Campaigns</li>
							<li> - Creative Direction</li>
						</ul>
					</div>
					<div class="col-sm-12 col-md-12 col-lg-6">
						<ul class="list-unstyled">
							<li> - Packaging</li>
							<li> - Typography</li>
							<li> - Typography</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- About -->
<!-- Portfolio -->
<section class="portfolio">
	<div class="container">
		<div class="row text-center align-items-center mb-5">
			<div class="col-lg-6">
				<p class="para-three">As a full-service design agency,
					we work closely with our clients to define,
					design, and develop transformative user
					experiences across all platforms and
				brand’s touch points.</p>
			</div>
			<div class="col-lg-6">
				<div class="img-boxs">
					<img src="/assets/images/about/project-side-img.png" class="img-fluid" alt="">
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="port col-12 col-sm-3 col-md-3 col-lg-3">
				<div class="img-box">
					<a href="/assets/images/about/slide-1.jpg" data-fancybox="logotab">
						<img src="/assets/images/about/slide-1.jpg" class="img-fluid" alt="">
						<div class="overlay-portfolio">
							<i class="fas fa-search-plus mb-2"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="port col-12 col-sm-3 col-md-6 col-lg-6">
				<div class="img-box">
					<a href="/assets/images/about/slide-2.jpg" data-fancybox="logotab">
						<img src="/assets/images/about/slide-2.jpg" class="img-fluid" alt="">
						<div class="overlay-portfolio">
							<i class="fas fa-search-plus mb-2"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="port col-12 col-sm-3 col-md-3 col-lg-3">
				<div class="img-box">
					<a href="/assets/images/about/slide-3.jpg" data-fancybox="logotab">
						<img src="/assets/images/about/slide-3.jpg" class="img-fluid" alt="">
						<div class="overlay-portfolio">
							<i class="fas fa-search-plus mb-2"></i>
						</div>
					</a>
				</div>
			</div>
			
		</div>
	</div>
</section>
<!-- Portfolio -->
<!-- Let's Talk -->
<section class="lets-talk">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="heading-three">We have Digital Solution for Everyone <strong>Let’s help you find more clients and grow your Business</strong></h2>
				<ul class="list-unstyled mb-0 mt-5">
					<li class="list-inline-item"><a href="#" class="btn btn-simple">Let’s Talk</a></li>
					<li class="list-inline-item"><a href="#" class="btn btn-simple">Let’s Get Started</a></li>
				</ul>
			</div>
		</div>
	</div>
</section>
<!-- Let's Talk -->
<!-- Testimonial -->
<?php include '../partial/testimonials.php'; ?>
<!-- Testimonial -->

<!-- Footer -->
<?php include '../partial/footer.php'; ?>
<!-- Footer -->
<!-- Footer Script -->
<?php include '../partial/footer_script.php'; ?>
<!-- Footer Script -->